# NVS chocolatey package

Chocolatey package for [nvs](https://github.com/jasongin/nvs/)

## Test the package locally

To test this package locally you will need to:

1. Install [Chocolatey](https://chocolatey.org/install)
1. Open an elevated PowerShell window
1. From the root of the project, execute `choco pack`
1. Then run `choco install nvs -dv -s .`

For more information you can check the [Chocolatey documentation](https://chocolatey.org/docs/create-packages)
